//
//  optionsMenu.swift
//  SkinCare Project
//
//  Created by TDI Student on 28.9.22.
//

import Foundation

struct optionsMenu {
    var title: String
    var segue: String?
}
