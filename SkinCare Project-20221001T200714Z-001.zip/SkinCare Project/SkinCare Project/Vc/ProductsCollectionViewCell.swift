//
//  ProductsCollectionViewCell.swift
//  SkinCare Project
//
//  Created by TDI Student on 29.9.22.
//

import UIKit

class ProductsCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var productImg: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        //  code
    }
    func setDetails(products : Products){
        productImg.image = UIImage(named: products.image ?? "")
        nameLabel.text = products.name ?? ""
        productImg.layer.cornerRadius = 15
    }

    
}
