//
//  ViewController.swift
//  SkinCare Project
//
//  Created by TDI Student on 19.9.22.
//

import UIKit
import Lottie
import Kingfisher

class MainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

}

