//
//  Products.swift
//  SkinCare Project
//
//  Created by TDI Student on 29.9.22.
//

import Foundation
class Products{
    var image : String?
    var name : String?
    var Description: String?
    
    init(image:String?,name:String?,Description:String?){
        self.image=image
        self.name=name
        self.Description = Description
    }
}
